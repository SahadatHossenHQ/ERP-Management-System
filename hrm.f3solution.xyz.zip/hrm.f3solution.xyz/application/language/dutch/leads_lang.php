<?php
$lang['recent_leads'] = 'Alle leidingen';
$lang['source'] = ' Bron';
$lang['facebook_profile_link'] = ' Facebook URL';
$lang['twitter_profile_link'] = ' Twitter URL';
$lang['linkedin_profile_link'] = ' Linkedin URL';
$lang['leads_name'] = ' Leads Naam';
$lang['mettings_deleted'] = ' Vergaderingen deel informatie succesvol verwijderd';
$lang['convert'] = '  Converteren';
$lang['convert_to_client'] = ' Converteren naar Client';
$lang['activity_convert_to_client'] = ' Omzetten Lead To Client';
$lang['convert_to_client_suucess'] = ' Omzetten Lead Client Om succesvol';
$lang['import_leads'] = ' import Leads';


/* End of file leads_lang.php */
/* Location: ./application/language/dutch/leads_lang.php */
