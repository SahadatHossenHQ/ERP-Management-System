<?php
$lang['recent_leads'] = 'sdddddddddddddda';
$lang['source'] = 'asd';
$lang['facebook_profile_link'] = 'sddsaads';
$lang['twitter_profile_link'] = 'Kilde';
$lang['linkedin_profile_link'] = 'Kilde';
$lang['leads_name'] = 'Kilde';
$lang['mettings_deleted'] = 'Kilde';
$lang['convert'] = 'Kilde';
$lang['convert_to_client'] = 'Kilde';
$lang['activity_convert_to_client'] = 'Kilde';
$lang['convert_to_client_suucess'] = 'Kilde';
$lang['import_leads'] = 'Kilde';
$lang['all_leads'] = 'All Leads';
$lang['new_leads'] = 'New Leads';
$lang['lead_name'] = 'Title';
$lang['contact_name'] = 'Contact Name';
$lang['state'] = 'State';
$lang['leads'] = 'Leads';
$lang['leads_details'] = 'Leads Details';
$lang['call'] = 'Call';
$lang['mettings'] = 'Meetings';
$lang['call_summary'] = 'Call Summary';
$lang['contact'] = 'Contact With';
$lang['responsible'] = 'Responsible';
$lang['all_call'] = 'All Call';
$lang['new_call'] = 'New Call';
$lang['all_metting'] = 'All Meetings';
$lang['new_metting'] = 'New Meetings';
$lang['metting_subject'] = 'Meetings Subject';
$lang['activity_leads_attachfile_deleted'] = 'Leads Attachment File Delete';
$lang['save_leads_call'] = 'Save Leads Call information successfully';
$lang['activity_save_leads_call'] = 'Save Leads Call Deatils';
$lang['activity_update_leads_call'] = 'Update Leads Call Deatils';
$lang['update_leads_call'] = 'Update Leads Call information successfully';
$lang['activity_leads_call_deleted'] = 'Leads Call Deleted';
$lang['leads_call_deleted'] = 'Leads Call information successfully deleted!';
$lang['save_leads_metting'] = 'Save Leads Meetings information successfully';
$lang['activity_save_leads_metting'] = 'Save Leads Meetings Deatils';
$lang['activity_update_leads_metting'] = 'Update Leads Meetings Deatils';
$lang['update_leads_metting'] = 'Update Leads Meetings information successfully';
$lang['activity_leads_metting_deleted'] = 'Leads Meetings Delete';
$lang['leads_metting_deleted'] = 'Leads Meetings information successfully deleted';
$lang['by_status'] = 'By Status';
$lang['by_source'] = 'By Source';


/* End of file leads_lang.php */
/* Location: ./application/language/danish/leads_lang.php */
