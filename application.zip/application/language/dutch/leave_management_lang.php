<?php
$lang['leave_management'] = 'Laat beheer ';
$lang['my_leave'] = ' mijn Verlof';
$lang['all_leave'] = ' alle Leave';
$lang['new_leave'] = ' nieuwe Leave';
$lang['leave_report'] = ' Laat Report';
$lang['all_required_fill'] = ' Gelieve Vul alle vereiste vulling toe te passen';
$lang['current_date_error'] = ' U kunt niet solliciteren naar verlaat de huidige dag';
$lang['end_date_less_than_error'] = ' De einddatum kan niet lager zijn dan de startdatum zijn  ';
$lang['leave_successfully_save'] = ' Laat Informatie Succesvol Opgeslagen';
$lang['leave_date_conflict'] = ' conflict: Je hebt al verlof in de geselecteerde tijd';
$lang['application_details'] = ' Application Details';
$lang['leave_from'] = ' toegepast Van';
$lang['leave_to'] = ' naar';
$lang['details_of'] = ' Details van';
$lang['applied_on'] = ' Applied On';
$lang['at'] = ' op';
$lang['approved_by'] = ' Goedgekeurd door';
$lang['approved'] = ' aangenomen';
$lang['reject'] = ' afwijzen';
$lang['rejected'] = ' Verworpen';
$lang['give_comment'] = ' Geef commentaar';
$lang['application_status_changed'] = ' Application Status succes gewijzigd';
$lang['leave_application_delete'] = ' Application Status succesvol verwijderen';
$lang['activity_leave_deleted'] = ' Verlofaanvraag Deleted  ';
$lang['activity_leave_save'] = ' Nieuwe verlofaanvraag Saved';
$lang['activity_leave_change'] = ' Application Status chnaged';


/* End of file leave_management_lang.php */
/* Location: ./application/language/dutch/leave_management_lang.php */
