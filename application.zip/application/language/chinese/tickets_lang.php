<?php
$lang['tickets'] = '门票';
$lang['edit_ticket'] = '编辑门票';
$lang['delete_ticket'] = '删除票';
$lang['create_ticket'] = '创建门票';
$lang['all_tickets'] = '所有门票';
$lang['new_ticket'] = '新门票';
$lang['ticket_details'] = '票务详情';
$lang['department'] = '部';
$lang['new_department'] = '新科';
$lang['select_department'] = '选择部门';
$lang['ticket_code'] = '票码';
$lang['ticket_message'] = '票务信息';
$lang['resourcement'] = '票务信息';
$lang['ticket_created'] = '票务信息';
$lang['ticket_replied'] = '票务信息';
$lang['ticket_status'] = '票务信息';
$lang['reply_ticket'] = '票务信息';
$lang['ticket_deleted_successfully'] = '票务信息';
$lang['activity_ticket_status_changed'] = '票务信息';
$lang['ticket_status_changed'] = '票务信息';
$lang['seconds'] = '票务信息';
$lang['task_deleted'] = '票务信息';
$lang['ticket_edited_successfully'] = '票务信息';
$lang['email_template'] = '票务信息';
$lang['ticket_staff_email'] = '票务信息';
$lang['ticket_client_email'] = '票务信息';
$lang['ticket_reply_email'] = '票务信息';
$lang['ticket_closed_email'] = '票务信息';
$lang['departments'] = '票务信息';
$lang['department_name'] = '票务信息';
$lang['department_added'] = '票务信息';
$lang['income_category_added'] = '票务信息';
$lang['payment_method_added'] = '票务信息';
$lang['payment_method_deleted'] = '票务信息';
$lang['bill_no'] = '票务信息';
$lang['languages'] = '票务信息';
$lang['add_file'] = '票务信息';
$lang['user_edit_login'] = '票务信息';
$lang['minor'] = '票务信息';
$lang['major'] = '票务信息';
$lang['show_stopper'] = '票务信息';
$lang['must_be_fixed'] = '票务信息';
$lang['reproducibility'] = '票务信息';
$lang['your_balance_due'] = '票务信息';
$lang['overdue'] = '票务信息';
$lang['recently_paid_invoices'] = '票务信息';
$lang['recent_tickets'] = '票务信息';
$lang['this_month'] = '票务信息';
$lang['last_30_days'] = '票务信息';


/* End of file tickets_lang.php */
/* Location: ./application/language/chinese/tickets_lang.php */
